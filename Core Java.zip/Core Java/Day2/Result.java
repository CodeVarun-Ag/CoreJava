
public class Result {
	public static void main(String[] ar)
	{
		float m=80.2f;
		if(m>=75)
			System.out.println("I DIV HONS");
		else if(m>=60&&m<75)
			System.out.println("I DIV");
		else if(m>=50 && m<60)
			System.out.println("II DIV");
		else
			System.out.println("Fail");
	}
}
