
public class Pattern1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		for(i=1;i<4;i++)
		{
			for(j=1;j<=i;j++)
				System.out.print("1");
			System.out.println();
		}
		

	}

}
