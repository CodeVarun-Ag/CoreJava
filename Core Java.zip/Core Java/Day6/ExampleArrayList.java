import java.util.*;
public class ExampleArrayList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al = new ArrayList<String>();
		al.add("Hello");
		al.add("Everyone");
		al.add("How");
		System.out.println(al);
		
	}

}
