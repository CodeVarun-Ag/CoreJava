
public class StudentAvg {

	/**
	 * @param args
	 */
	int m1,m2;
	String name;
	float avg;
	public float calavg()
	{
		avg=(m1+m2)/2;
		return avg;
	}
	public void display()
	{
		System.out.println("Name : "+name + "\n Average marks : "+avg);
	}
	
}
