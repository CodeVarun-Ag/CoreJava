
public class ClassExample {

	/**
	 * @param args
	 */

	String color,brand;
	int len;
	public void call()
	{
		System.out.println("Calling..");
	}
	public void message () {
		System.out.println("Messaging");
	}
	public void display() {
		System.out.println("Color is : "+color+"\n  Brand is : "+brand+"  \nLEngth is : "+len);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassExample c =new ClassExample();
		c.color="Blue";
		c.len=143;
		c.brand="Samsung";
		c.display();
				

	}

}
