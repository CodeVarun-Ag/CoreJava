	
public class Dog extends Animal {

	/**
	 * @param args
	 */
	void color()
	{
		System.out.println("All colors available");
	}
	
	void bark()
	{
		System.out.println("I can bark");
	}
	
	void run()
	{
		System.out.println("I can run also");
	}
}
