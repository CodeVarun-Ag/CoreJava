
public class NewAccount {

	/**
	 * @param args
	 */
	int no;
	 float bal,rate;
	 public NewAccount()
	 {}
	 
	 public NewAccount(int no)
	 {
		 this.no=no;
	 }
	 public NewAccount(int no, float bal , float rate) {
		this.no=no;
		this.bal=bal;
		this.rate=rate;
	} 
	 
	 public String get_acc_details()
	 {
		 String str= "Account no. : "+ no + "\n" + " Account Balance : "+ bal +"\n" + "Interest Rate : "+ rate;
		 return str;
	 }
	 
	 public float cal_Interest(float amt)
	 {
		 return amt*rate/100;
	 }
	
	 public boolean withdraw(float amt)
		{
			if(bal-amt >=500)
			{
				bal=bal-amt;
				return true;
			}
			return false;
		}
		
		 public void deposit(float amt) {
			 bal=bal+amt;
			
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NewAccount n= new NewAccount(1234);
		NewAccount n1= new NewAccount(1234, 500000, 8);
		System.out.println(n1.get_acc_details());
		System.out.println(n.get_acc_details());
	}

}
