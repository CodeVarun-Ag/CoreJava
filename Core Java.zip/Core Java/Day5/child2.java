import parent.Parent;


public class child2 extends Parent{
	public static void details()
	{
//				System.out.println(a);
//				System.out.println(b);
				System.out.println(c);
				System.out.println(d);
	}
	public static void main(String[] ar)
	{
		//System.out.println(a);
		//System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
		details();
	}
}
