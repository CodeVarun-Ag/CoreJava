package learn;

public class parentclass {
	//accessed only in the same class
	private int a =10;
	
	//accessed by the same class and the classes in the same package
	int b =20;
	
	//accessed by the same class and the classes in the same package
	//and also by sub classes
	// means using inheritance
	protected int c = 30;
	
	//accessed from anywhere
	public int d = 40;
	
	public void display(){
		System.out.println(a);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parentclass ob = new parentclass();
		System.out.println(ob.a);
		System.out.println(ob.b);
		System.out.println(ob.c);
		System.out.println(ob.d);
	}

}
