package learn;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class sheet {

	public int read(int r, int c){
		int s =0;
		try {
		File f = new File("C:\\Users\\ranvijay.singh\\Documents\\Book2.xlsx");
		FileInputStream fin = new FileInputStream(f);
	
		XSSFWorkbook wb = new XSSFWorkbook(fin);
		XSSFSheet sw = wb.getSheet("number");
		XSSFRow rw = sw.getRow(r);
		XSSFCell ce =rw.getCell(c);
	
		s = (int)(ce.getNumericCellValue());
		
	}
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return s;
	}
	
	
	public void write(int r, int c,int data ,String Sheet){
		try {
		File f = new File("C:\\Users\\ranvijay.singh\\Documents\\Book2.xlsx");
		FileInputStream fin = new FileInputStream(f);
	
		XSSFWorkbook wb = new XSSFWorkbook(fin);
		XSSFSheet sw = wb.getSheet(Sheet);
		XSSFRow rw = sw.createRow(r);
		XSSFCell ce =rw.createCell(c);
	
		ce.setCellValue(data);
		FileOutputStream fos = new FileOutputStream(f);
		wb.write(fos);
		
	}
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
	public int even(int data){
		int flag = 0 ;
		if(data%2 == 0){
			flag = 1 ;
		}
		return flag;
	}
	
	public int odd(int data){
		int flag = 1 ;
		if(data%2 != 0){
			flag = 0;
		}
		return flag;
	}
	public int prime(int data){
		int flag = 2;
		 for(int i = 2; i <= data/2; ++i)
	        {
	            // condition for nonprime number
	            if(data % i == 0)
	            {
	                flag = 1;
	                break;
	            }
	            
	        }
		 return flag;
	}
}
