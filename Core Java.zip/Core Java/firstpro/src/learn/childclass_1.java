package learn;

public class childclass_1 extends parentclass{
	
	public static void main(String[] args){

		parentclass ob = new parentclass();
			
		System.out.println(ob.d);
		System.out.println(ob.c);
		System.out.println(ob.b);
		
			ob.display();
	}

}