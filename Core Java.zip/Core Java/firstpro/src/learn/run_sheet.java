package learn;

public class run_sheet {
	
	public static void main(String[] args){
		
		sheet s1 = new sheet();
		
		int j=0, k =0, l=0;
		for(int i = 0 ;i<=9 ;i++){
			
		int a  = s1.read(i, 0);
		System.out.println(a);
		
		if(s1.even(a)== 1){
			s1.write(j, 0, a, "even");
			j++;
		}
		
		if(s1.odd(a)== 0){
			s1.write(k, 0, a, "odd");
			k++;
		}
		
		if(s1.prime(a)== 2){
			s1.write(l, 0, a, "prime");
			l++;
		}	
			}
		}
	}

