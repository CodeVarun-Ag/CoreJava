package learn;

public class ex1 {

	public static void main(String[] args) {
		try{
		int a = 10,b =0,d;
		d =a/b;
		int[] a1 ={1,4,5,6};
		System.out.println(a1[3]);
		System.out.println(a1[4]);
		System.out.println(d);
		}
		catch(ArithmeticException e){
			System.out.println("in catch block - Airthmetic Exception");
		}
		catch(ArrayIndexOutOfBoundsException ae){
			System.out.println("in catch block - Array out of bounds Exception");
		}
		
		System.out.println("out of block");
	}

}
