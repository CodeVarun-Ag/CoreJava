package abstraction_1;

abstract class emp {
	int emp_id;
	String e_name;
	int rateperunit;
	


	
	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public String getE_name() {
		return e_name;
	}

	public void setE_name(String e_name) {
		this.e_name = e_name;
	}

	public int getRateperunit() {
		return rateperunit;
	}

	public void setRateperunit(int rateperunit) {
		this.rateperunit = rateperunit;
	}

	abstract int cal_monthly_salary();

	emp(int emp_id,String e_name, int rateperunit){
	this.emp_id = emp_id;
	this.e_name = e_name;
	this.rateperunit = rateperunit;

}
}
