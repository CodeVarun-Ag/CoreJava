package abstraction_1;

public class fte extends emp{
fte(int totaldayswork, int emp_id, String e_name, int rateperunit) {
		super(emp_id, e_name, rateperunit);
		this.totaldayswork = totaldayswork; 
		// TODO Auto-generated constructor stub
	}

int totaldayswork;

int cal_monthly_salary(){
	int salary = totaldayswork *rateperunit;
	return salary;
}
}
