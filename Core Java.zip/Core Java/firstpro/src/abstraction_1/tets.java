package abstraction_1;

public class tets{
	
	public static void main(String[] args){
		consultant ob =new consultant(4, 4, "ramesh", 5);
		fte ob1 = new fte(2, 1, "mahesh", 6);
		System.out.println(ob.cal_monthly_salary());
		System.out.println(ob1.cal_monthly_salary());

		ob1.setE_name("ram");
		System.out.println(ob1.getE_name());
	}
}
