package abstraction_1;

public class consultant extends emp{
consultant(int totalhourswork , int emp_id, String e_name, int rateperunit) {
		super(emp_id, e_name, rateperunit);
		// TODO Auto-generated constructor stub
		this.totalhourswork = totalhourswork;
	}

int totalhourswork;

public int cal_monthly_salary(){
	int salary = totalhourswork *rateperunit;
	return salary;
}
}
