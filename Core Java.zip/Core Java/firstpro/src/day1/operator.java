package day1;

public class operator {
	
	public static void main(String[] args){
	int a=10,c =5,b =20;
	System.out.println(a<b);
	System.out.println(b>c);
	
	System.out.println((a>b) && (a>c));
	System.out.println((a>b) || (a>c));
	System.out.println(!((a>b) || (a>c)));
	

	}
	

}
