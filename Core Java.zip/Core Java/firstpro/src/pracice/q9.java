package pracice;

public class q9 {
	public static int multiply(int x, int y){
		int z = x*y;
		return z;
	}
	
public static void main(String[] args){
	int i = 5,j = 4;
	
	for(int k =1;k<=5;k++){
	System.out.println(i + "*"+j + " = "+ multiply(i,j));
	i=i+1;
	j=j+2;
}
}
}
