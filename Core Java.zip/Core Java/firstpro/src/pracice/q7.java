package pracice;

public class q7 {

	public static void main(String[] args) {
		int sp=0;
		for(int i =5;i>0;i--){
			for(int k =0;k<sp;k++){
				System.out.print(" ");
			}
			for(int j =0;j<i;j++){
			System.out.print(i);	
			}
			System.out.println();
			sp++;
		}
	}

}
