package pracice;

public class q11 {
	
	public static int prime(int data){
		int flag = 2;
		 for(int i = 2; i <= data/2; ++i)
	        {
	            // condition for nonprime number
	            if(data % i == 0)
	            {
	                flag = 1;
	                break;
	            }
	            
	        }
		 return flag;
	}
	
public static void main(String[] args){
	int sum = 0;
	int c =0;
	for(int i=2;i<=50;i++){
		if(prime(i)== 2){
			c++;
			
		if(c>5 && c<=10){
			System.out.println(i);
			sum = sum+i;
		}
		
		}
	}
	System.out.println("sum :" +sum);
}

}
