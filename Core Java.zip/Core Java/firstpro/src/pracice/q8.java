package pracice;

public class q8 {

	
	public static void main(String[] args) {
		int sp =4;

		for(int i =1;i<=5;i++){
			for(int k =0;k<sp;k++){
			System.out.print(" ");
			}
			sp--;
			for(int j =1;j<=i;j++){
			System.out.print(i+" ");
			
			}
			System.out.println();
		}
		sp=sp+2;
		for(int i =4;i>=1;i--){
			for(int k =0;k<sp;k++){
			System.out.print(" ");
			}
			sp++;
			for(int j =1;j<=i;j++){
			System.out.print(i+" ");
			
			}
			System.out.println();
		}
		

	}

}
