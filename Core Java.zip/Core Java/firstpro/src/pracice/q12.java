package pracice;

public class q12 {
	public static int prime(int data){
		int flag = 2;
		 for(int i = 2; i <= data/2; ++i)
	        {
	            // condition for nonprime number
	            if(data % i == 0)
	            {
	                flag = 1;
	                break;
	            }
	            
	        }
		 return flag;
	}
	
	public static void main(String[] args){
		int c =0, sum =0;
		for(int i = 2; i<=200;i++){
			if(prime(i) == 2){
			System.out.println(i);
			c++;
				}
			if(c>=2){
				sum = sum+i;
			}
		}
	}
}
