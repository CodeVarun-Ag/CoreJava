package static_1;

public class emp {
	//for every object it has a separate value/copy
	int c =0;
	//there will be only one variableand its value is  shared by every object
	//saves lot of memory
	static int b=0;
	
	public emp(){
		c++;
		b++;
	}
	
}
