package static_1;

public class test_emp {
	
	public static void main(String[] args){
	emp d = new emp();
	System.out.println(d.b + " "+ d.c);
	
	emp d1 = new emp();
	System.out.println(d1.b + " "+ d1.c);
	}
}
