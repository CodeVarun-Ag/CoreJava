package enscapulation;

import learn.parentclass;

public class childclass_2 extends parentclass{
	
	
	public void details(){

//		System.out.println(a);
//		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
	}

}
