package enscapulation;

public class test{

	public static void main(String[] args){
		childclass_2 ob = new childclass_2();
		
	ob.details();
	}
}
