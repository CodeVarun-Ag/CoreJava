package enscapulation;

public class acc_test {
public static void main(String[] args)



{
	
	account a1 = new account();
	a1.setAccount_bal(2345);
	a1.setAccount_no(1234);
	
	System.out.println(a1.getAccount_bal());
	System.out.println(a1.getAccount_no());
}
}
