package enscapulation;

public class account {

	private int account_no;
	public int getAccount_no() {
		return account_no;
	}
	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}
	public float getAccount_bal() {
		return account_bal;
	}
	public void setAccount_bal(float account_bal) {
		this.account_bal = account_bal;
	}
	private float account_bal;
	
//	public int getAccount_no() {
//		return account_no;
//	}
//	public void setAccount_no(int account_no) {
//		this.account_no = account_no;
//	}
//	public float getAccount_bal() {
//		return account_bal;
//	}
//	public void setAccount_bal(float account_bal) {
//		this.account_bal = account_bal;
	}

