package prime;

public class zoo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		elephant ele = new elephant();
		ele.age = 24;
		ele.color = "blue";
		ele.id = 1;
		ele.len_of_tail  = 23;
		ele.len_of_trunk = 25;
		ele.action = "roam";
		ele.name = "jumbo";
		ele.no_of_leg =4;
		ele.eat();
		ele.display_items();
		
	}

}
