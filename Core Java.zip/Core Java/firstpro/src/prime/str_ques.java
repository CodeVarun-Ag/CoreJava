package prime;

public class str_ques {
	
public static void main(String[] args){
	
	String s ="I am learning core java";
	int i=0,c=0;
	
	while(s.indexOf('a',i)!= -1){
		i = s.indexOf('a',i)+1;
		c++;
		}
	 
	System.out.println(c);
}
}
