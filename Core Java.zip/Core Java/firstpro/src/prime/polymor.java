package prime;

public class polymor {

	public int add(int x, int y){
		int z = x+y;
		return z;
	}
	
	public float add(float x, float y){
		float z = x+y;
		return z;
	}
	
	public int add(int x, int y, int z){
		int m = x+y+z;
		return m;
	}
	
	public float add(float x, float y, float z){
		float m = x+y+z;
		return m;
	}

	public static void main(String[] args){
		
		polymor c1 = new polymor();
		System.out.println(c1.add(3, 5));
		System.out.println(c1.add(3.5f, 5.7f));
		System.out.println(c1.add(3, 5, 7));
		System.out.println(c1.add(3.0f, 5.8f, 8.f));
		
	}
}
