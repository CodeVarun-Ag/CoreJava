package prime;

import java.util.Scanner;

public class vowel {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		char ch = input.next().charAt(0);
		System.out.println(ch);
		 
		
		if(ch == 'a' || ch =='e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch =='E' || ch == 'I' || ch == 'O' || ch == 'U'){
			System.out.println(ch + " character is vowel ");
		}
		else{
			System.out.println(ch + " character is constant");
		}
	}
}
