package prime;

public class array_sum {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m[] = {22,33,44,56,66};
		int sum =0;
		double avg;
		for(int i =0;i<=4;i++){
			sum = sum+m[i];
		}
		avg = sum/4;
		System.out.println(avg);
		for(int i =0;i<=4;i++){
			if(m[i]>=avg){
				System.out.println(m[i]);
			}
		}

	}

}
