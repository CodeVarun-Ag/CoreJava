package prime;

public class armstrong {
	
public static void main(String[] args){

	int num = 153;
	int s =0;
	int rem = 1;
	int temp = num;
	
	while(temp != 0){
	rem = temp % 10;
	s = s + rem*rem*rem;
	temp = temp/10;
		}
	
	if(num == s){
	System.out.println(num +" is a armstrong number");
	}
	else{
		System.out.println(num +" is not a armstrong number");
	}
	}
}
