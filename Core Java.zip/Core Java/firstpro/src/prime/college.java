package prime;

public class college {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1 = new student();
		student s2 = new student();
		
		s1.marks1 = 40;
		s1.marks2 = 50;
		s1.name = "ramesh";
		s1.display();
		 
		s2.marks1 = 60;
		s2.marks2 = 70;
		s2.name = "mahesh";
		s2.display();
		
		
		if(s1.avg() > s2.avg()){
			System.out.println(s1.name + " with " + s1.avg()+ " has scored max marks " );
		}
		else{
			System.out.println(s2.name + " with " + s2.avg() + " average marks "+ " has scored max marks " );
		}

	}

}
