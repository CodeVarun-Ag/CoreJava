package prime;

public class elephant extends animal {
float len_of_trunk;
int no_of_tusks;
int len_of_tail;

public void roam(){
	System.out.println("they roam");
}

}
