package prime;

public class wage_bill {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int unit = 150;
		float sum = 0.0f;

		if(unit <= 100){
			sum =sum +  (unit * 1.50f);
			System.out.println(sum);
		}
		else if(unit <=200){
			sum = sum + (100 * 1.50f)+ ((unit-100)*2.0f);
			System.out.println(sum);
		}
		else if(unit <=250){
			sum = sum + (100 * 1.50f)+ (100*2.0f) + ((unit-50)*2.0f);
			System.out.println(sum);
		}
		else{
			sum = sum + (100 * 1.50f) +( 100 *2.0f) + (50 *2.50f) + ((unit-250)* 4.0f);
			System.out.println(sum);
	}
			
		
	}

}
