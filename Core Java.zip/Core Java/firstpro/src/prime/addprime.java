package prime;

public class addprime {
	public static boolean isprime(int x){
		boolean flag =true;
		if(x ==2){
			return flag;
		}
		else{
			for(int i =2;i<x;i++){
				if (x%i == 0){
				flag = false;
				break;
				}
			}
		}
		return flag;
	} 

	public static void main(String[] args){
		int num = 2, sum =0,p=0;
		while(true){
			
			if(p==10){
				break;
			}
			if(isprime(num)){
				System.out.println("prime"+num);
				sum =sum+num;
				p++;
			}
			num =num+1;
		}
		System.out.println("sum"+sum);
	}
}
