package prime;

public class for_loop {
public static void main(String[] args){
	int sum =0;
	
	for(int i =10;i<=30;i++){
		if(i%3 == 0){
			System.out.println(i + " is divisible by 3");
			sum =sum+i;
			}
	}
	System.out.println(sum + "sum");
	
}
}
