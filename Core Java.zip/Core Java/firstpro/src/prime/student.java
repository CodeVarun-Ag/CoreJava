package prime;

public class student {
	int marks1;
	int marks2;
	String name;
	
	public double avg(){
		int z;
		z = ((marks1+marks2)/2);
		return z;
	}
	
	public void display(){
		System.out.println("marks1 "+ marks1+ " marks2 " +marks2 +" name " +name);
	}
}
