package prime;

public class str1 {

	public static void main(String[] args){
		String s = "I am learning core java", s1 ="hello" , s2 = "Hello", s3;
		int l = s.length();
		System.out.println("length: " + l);
		
		System.out.println(s1.compareTo(s2));
		
		System.out.println(s1.compareToIgnoreCase(s2));
		
		System.out.println(s1.compareTo(s2));
		
		s3 = s.substring(0,5);
		System.out.println(s3);
		
		
		int p = s.indexOf('a');
		System.out.println(p);
		int m = s.indexOf('a',2);
		System.out.println(m);
		
		int n = s.indexOf('z',3);
		System.out.println(n);
		
		s3 = s.substring(2,4);
		System.out.println(s3);
		
	}
}
