package prime;

public class animal {
 int id;
 int age;
 String name;
 String type;
 float weight;
 String color;
 int no_of_leg;
 String action;
 
 public void display_items(){
	 System.out.println("id " +id + " age " +age + " name " + "Type" + type + " Weigth " + weight
			 +" color " + color + " no_of_leg " + no_of_leg + " action " + action);
	}
 
 public void eat(){
	 System.out.println("they eat");
 }
 
 public void sleep(){
	 System.out.println("they sleep");
 }

}
