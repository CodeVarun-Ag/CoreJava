package prime;

public class mobile {
	String color;
	float len;
	float breadth;
	String brand;
	
	
	public void call(){
	System.out.println("calling");	
	}
	
	public void msg(){
		System.out.println("messaging");
	}

	public void displayitems(){
		System.out.println("length = "+len +" breadth= "+ breadth+" brand= "+brand+" color= "+color);
}
	
}
