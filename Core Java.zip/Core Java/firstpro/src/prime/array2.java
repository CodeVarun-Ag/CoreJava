package prime;

public class array2 {
public static void main(String[] args){
	int[] m = {21,34,91,59,16,44,65,77,31,54};
	int num =65;
	for(int i=0;i<10;i++){
		for(int j=0;j<10;j++){
			if((m[i]+m[j]) == num){
				System.out.println(m[i]+ "+" + m[j]+ "=" + num);
			}
		}
	}
}
}
