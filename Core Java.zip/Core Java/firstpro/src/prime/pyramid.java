package prime;

public class pyramid{
	public static void main(String[] args){
		int num = 9,sp =3;
		int i,j;
		
		
		for(i =0;i<=4;i++){
			
			for(j =0;j<=sp;j++){
				System.out.print(' ');
			}
			
			for(int k = 1;k<=4-sp;k++){
				System.out.print(num+" ");
			}
			
		num = num-2;
		sp--;
		System.out.println();
		}
		sp =1;
		num = num+4;
		
		for(i= 0; i<3;i++){
			
			for(j = 0;j<sp;j++){
				System.out.print(" ");
				}
			for(int k = 0;k<4-sp;k++){
				System.out.print(num +" ");
			}
			num =num+2;
			sp++;
			System.out.println();
		}
	}
	}


