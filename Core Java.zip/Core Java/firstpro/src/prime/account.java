package prime;

public class account {
	int accountno;
	double accountbal;
	double int_rate;
	String accname;
	
	
	
	
	public String get_account_det(){
		String str = "Account Number: " + accountno + "\n"
				+ "Account Balance: " + accountbal + "\n"
				+ "Interest Rate: " + int_rate+ "ACCname :"+accname;
		
		return str;
	}
	
	public double get_interest(double amt,double time)
	
	{
		return (amt*int_rate*time)/100;
		
	}
	public double total_amount(double amt,double time)
	{
		return amt+(amt*int_rate*time)/100;
	}
}
