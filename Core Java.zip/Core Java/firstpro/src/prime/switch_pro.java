package prime;

public class switch_pro {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=12;
		switch(n)
		{
		case 5:
			System.out.println("5");
			break;
			
		case 7:
			System.out.println("7");
			break;
			
		case 9:
			System.out.println("9");
			break;
			
		case 12:
			System.out.println("12");
			break;
			
		default:
			System.out.println("n is not matched");
			break;
		}

	}

}
