package prime;

import java.util.Scanner;

public class even_odd {

	public static void main(String[] args){
		Scanner input = new Scanner(System.in); 
		int a;
		a  =input.nextInt();
		System.out.println(a);
		
		if(a%2 == 0){
			System.out.println(a + " nuber is even");
		}
		else{
			System.out.println(a + " number is odd");
		}
	}
}
