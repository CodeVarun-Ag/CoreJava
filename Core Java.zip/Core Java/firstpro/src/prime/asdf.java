package prime;

public class asdf {
	public static void main(String[] args){
		System.out.println("frr");
		
	}

}
