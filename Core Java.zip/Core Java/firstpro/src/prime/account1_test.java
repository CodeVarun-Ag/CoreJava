package prime;

public class account1_test {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		account1 acc1 = new account1(3145);
		System.out.println(acc1.get_account_det());
		
		account1 acc2 = new account1(3145,1000,9);
		System.out.println(acc2.get_account_det());
	}
}
