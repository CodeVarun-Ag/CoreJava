package prime;

import java.util.Scanner;

public class switc2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int n;
		n = input.nextInt();
		System.out.println(n);
		int temp = n,rem;
		while(temp>=0){
			rem = temp%10;
			temp = temp/10;
			switch(rem){
			case 1:
				System.out.println("one");
				break;
			
			case 2:
				System.out.println("Two");
				break;
				
			case 3:
				System.out.println("Three");
				break;
			
			case 4:
				System.out.println("four");
				break;
				
			case 5:
				System.out.println("five");
				break;
				
			case 6:
				System.out.println("six");
				break;
				
			case 7:
				System.out.println("Seven");
				break;
				
			case 8:
				System.out.println("eight");
				break;
				
			case 9:
				System.out.println("nine");
				break;
				
			default:	
				System.out.println("zero");
				break;
			}
		}

	}

}
