package prime;

public class opr_grade_1 {
	
public static void main(String[] args){
	float marks = 30.0f;
	
	if(marks>=75.0f){
		System.out.println("FCD");
	}
	else if(marks >= 60.0f){
		System.out.println("FC");
	}
	else if(marks >= 50.0f ){
		System.out.println("SC");
	}
	else if(marks >= 35.0f ){
		System.out.println("PC");
	}
	else{
		System.out.println("F");
	}
}
}
