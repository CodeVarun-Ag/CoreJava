package prime;

public class Fdaccount extends account {
	int duration;
	
	public void deposit(float depositAmt){
		accountbal =  depositAmt;
	}
	public double total_amount(double amt,double time)
	{
		return amt+(amt*int_rate*time)/100;
	}

}
