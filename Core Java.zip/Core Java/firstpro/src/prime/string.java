package prime;

public class string {

	public static void main(String[] args){
	String s1 = "I am learning core java";
	String[] words = s1.split(" ");
	
	int a = words.length;
	System.out.println(a);
	}
	}
