package prime;

public class Testaccount {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        sb_account s1 = new sb_account();
       
       s1.accountno=1234;
       s1.accountbal=32145;
       s1.accname= "Varun";
       s1.int_rate =7;
       s1.deposit(3456);
       
       s1.get_account_det();
       
	
	
	
	
	
	
	
	
	
	
	}

}
