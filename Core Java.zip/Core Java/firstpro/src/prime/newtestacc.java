package prime;

public class newtestacc {
	
	public static void main(String[] args){
		
		
		
		sb_account s1 = new sb_account();
	       
	       s1.accountno=1234;
	       s1.accountbal=32145;
	       s1.accname= "Varun";
	       s1.int_rate =7;
	       s1.get_account_det();
	}

}
