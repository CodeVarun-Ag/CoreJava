package prime;

public class testbank {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		bank b;
		b = new bank();
		System.out.println("rate of interest: "+ b.get_roi());
		
		b = new icici();
		System.out.println("rate of interest of icici: " + b.get_roi());
		
		b = new citi();
		System.out.println("rate of interest of citi: " + b.get_roi());
	}

}
