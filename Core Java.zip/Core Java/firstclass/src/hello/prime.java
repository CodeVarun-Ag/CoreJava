package hello;

public class prime{
	
	public  static boolean primeno(int x){
		boolean flag = true;
		for(int i =2;i<x;i++){
			if(x%i == 0){
				flag = false;
				break;
			}
		}
		return flag;
	}
	
	public static void main(String[] args){
		int sum =0,p =0;
		int i =2;
		while(true){
			if(p == 10){
				break;
			}
			if(primeno(i)== true){
				System.out.println("prime no:" + i);
				sum = sum+i;
				}
			i = i+1;
			System.out.println("sum is:"+sum);
		}
		
		}
	} 


