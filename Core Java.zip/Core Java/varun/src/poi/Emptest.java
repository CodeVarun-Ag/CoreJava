package poi;

public class Emptest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Emp e1 = new Emp();
		System.out.println(e1.b+ " "+e1.c);
		
		Emp e2 = new Emp();
		System.out.println(e2.b+ " "+e2.c);
		

	}

}
