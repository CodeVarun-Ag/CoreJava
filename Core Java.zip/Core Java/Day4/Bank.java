
public class Bank {
	float r_o_i;
	public float get_roi()
	{
		r_o_i=6f;
		return r_o_i;
	}

}
