package oops2;

public class testclass {

	
	public static void main(String[] args) {
		 childclass2 c1 = new childclass2();
		 c1.details();
		 
		 
	}

}
