package oops2;

import oops1.parentclass;

public class childclass2 extends parentclass
{

	/**
	 * @param args
	 */
	
	public void details()
	{
//		System.out.println(a);
//		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*parentclass p2 = new parentclass();
		System.out.println(p2.a);
		System.out.println(p2.b);
		System.out.println(p2.c);
		System.out.println(p2.d);
		*/
		

	}

}
