package oops1;

public class childclass1 extends parentclass {

	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//parentclass p1 = new parentclass();
		//System.out.println(p1.a);
		//System.out.println(p1.b);
		//System.out.println(p1.c);
		//System.out.println(p1.d);
		//p1.display();

	}

}
