package oops1;

public class testaccencaps {


public static void main(String[] args)

{
	accencaps acc1 = new accencaps();
	acc1.setAccbal(1000);
	acc1.setAccno(321);
	System.out.println("ACCNO :" +acc1.getAccno());
	System.out.println("ACCbal :" +acc1.getAccbal());
	
	
}




}