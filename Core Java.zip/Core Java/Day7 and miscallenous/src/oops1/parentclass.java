package oops1;

public class parentclass{

	/**
	 * @param args
	 */
	
	private int a=10;
	int b =20;
	protected int c = 30;
	public int d =40;
	
	
	public void display()
	{
		
		System.out.println(a);
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
