package oops1;

public class citi extends bank {
	
	public float getroi()
	{
		return 9.5f;
		
	}
}
