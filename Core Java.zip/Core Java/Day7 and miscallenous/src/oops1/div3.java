package oops1;

public class div3 {
	public static void main(String[] args){
		int n;
		for(int i=1;i<=10;i++)
		{
			n=3*i;
			System.out.println(n);
			
		}
		
		
		
	}

}
