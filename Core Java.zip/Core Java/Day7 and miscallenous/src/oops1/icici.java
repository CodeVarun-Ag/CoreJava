package oops1;

public class icici extends bank {
	
	public float getroi()
	{
		return 8.0f;
		
	}

}
