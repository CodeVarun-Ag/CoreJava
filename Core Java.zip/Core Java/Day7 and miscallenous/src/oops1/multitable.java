package oops1;

public class multitable {
	
	public static void main(String[] args)
	{
		int k=0,i;
		for(i=2;i<=4;i++)
		{
		k=(i+3)*(2*i);
		System.out.println(k);
		}
		
	}

}
