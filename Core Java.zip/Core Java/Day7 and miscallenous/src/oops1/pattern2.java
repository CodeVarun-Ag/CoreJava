package oops1;

public class pattern2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m=5,i,j;
		for(i=1;i<=5;i++)
		{
			for(j=5;j>=i;j--)
			{
				
				System.out.print(m);
				
			}
			m--;
			System.out.println();
		}

	}

}
