package oops1;

public class elephant {

}
