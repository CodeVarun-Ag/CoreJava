package oops1;

public class bank {
	
	public float getroi()
	{
		return 0f;
		
	}

}
