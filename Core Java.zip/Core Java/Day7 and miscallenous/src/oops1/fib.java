package oops1;

public class fib {

	/**
	 * @param args
	 */
	public int fib(int n)
	{
		int m=1;
		m=n;
		n=
	 return m+fib(n-1);
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
