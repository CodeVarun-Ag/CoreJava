package oops1;

public class mobiletest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		mobile smg = new mobile();
		smg.color = "black";
		smg.length = 4;
		smg.breadth = 5;
		smg.Brand = "Samsung";
		smg.call();
		smg.msg();
		smg.display();
		
		
		

	}

}
