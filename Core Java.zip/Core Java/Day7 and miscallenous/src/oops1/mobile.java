package oops1;

class mobile {
	
	String color;
	float length;
	float breadth;
	String Brand;
	
	public void call()
	{
		System.out.println("Mobile is calling");
		
	}

	public void msg()
	{
		System.out.println("Mobile is messaging");
		
	}
	public void display()
	{
		System.out.println("color="+color+"\n length is"+ length+"\n breadth is"+breadth+"\n Brand is"+ Brand);
		
	}
	
}
