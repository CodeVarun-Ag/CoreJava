package oops1;

public class accencaps {
	private int accno;
	private float accbal;
	int age;
	
	
	public int getAccno() {
		return accno;
	}
	
	public void setAccno(int accno) {
		this.accno = accno;
	}
	
	public float getAccbal() {
		return accbal;
	}
	
	public void setAccbal(float accbal) {
		this.accbal = accbal;
	}
	
	
	

}
